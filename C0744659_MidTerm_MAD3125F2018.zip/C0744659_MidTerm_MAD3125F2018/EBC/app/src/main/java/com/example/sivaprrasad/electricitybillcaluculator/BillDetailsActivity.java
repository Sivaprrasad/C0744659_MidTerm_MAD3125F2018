package com.example.sivaprrasad.electricitybillcaluculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BillDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_details);
    }
}
